#!/system/bin/sh
MODDIR=${0%/*}

# Wait for boot completion
while [ -z "$(getprop sys.boot_completed)" ]; do
    sleep 10
done

# Check if enable/disable
Uneed_file="/data/hollow/uneed"
if [ -f "$Uneed_file" ]; then
    uneed_value=$(cat "$Uneed_file" | tr -d '[:space:]')
    for pkg in com.samsung.android.game.gos com.xiaomi.powerchecker com.xiaomi.joyose; do
        if pm list packages | grep -q "$pkg"; then
            case "$uneed_value" in
                "1")
                    pm disable-user --user 0 "$pkg" >/dev/null 2>&1
                    log_activity "Disabled package: $pkg"
                    ;;
                "0")
                    pm enable "$pkg" >/dev/null 2>&1
                    log_activity "Enabled package: $pkg"
                    ;;
            esac
        fi
    done
fi

# Paths
Thermal_status="/data/hollow/thermal_mode"
Logging="/storage/emulated/0/hollow.log"
Default="standard"

if [ -f "$Thermal_status" ]; then
    thermal_mode_satus=$(cat "$Thermal_status" | tr '[:upper:]' '[:lower:]' | xargs)
    case "$thermal_mode_satus" in
        "Normal"|"Intense") ;; # Valid modes
        *) thermal_mode_satus="$Default" ;;
    esac
else
    thermal_mode_satus="$Default"
fi

#####################
# Logging function ###
####################

log_activity() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$Logging"
}

#####################################
## Common Thermal Functions ##
#####################################

disable_thermal_zones() {
    # Only modify if not already disabled
    for zone in /sys/class/thermal/thermal_zone*/mode; do
        if [ -f "$zone" ] && [ "$(cat "$zone")" != "disabled" ]; then
            chmod 644 "$zone"
            echo "disabled" > "$zone"
        fi
    done
    
    for zone2 in /sys/class/thermal/thermal_zone*/policy; do
        if [ -f "$zone2" ] && [ "$(cat "$zone2")" != "step_wise" ]; then
            echo "step_wise" > "$zone2"
        fi
    done
    
    log_activity "Disable Thermal Zones"
}

stop_thermal_services() {
    thermal_services() {
        find /system/etc/init /vendor/etc/init /odm/etc/init -type f 2>/dev/null | 
        xargs grep -h "^service" | awk '{print $2}' | grep thermal
    }
    
    for svc in $(thermal_services); do
        if [ "$svc" != "vendor.thermal-hal" ] && 
           [ "$svc" != "android.hardware.thermal-service.mediatek" ]; then
            if getprop | grep -q "init.svc.$svc.*running"; then
                stop "$svc"
                sleep 0.5
                pid=$(pidof "$svc")
                [ -n "$pid" ] && kill -9 "$pid"
            fi
        fi
    done
}

disable_gpu_limits() {
    if [ -f "/proc/gpufreq/gpufreq_power_limited" ]; then
        for setting in ignore_batt_oc ignore_batt_percent ignore_low_batt ignore_thermal_protect ignore_pbm_limited; do
            if ! grep -q "$setting 1" "/proc/gpufreq/gpufreq_power_limited"; then
                echo "$setting 1" > /proc/gpufreq/gpufreq_power_limited
            fi
        done
    fi
}

set_cpu_limits() {
    if [ -f /sys/devices/virtual/thermal/thermal_message/cpu_limits ]; then
        for cpu in 0 2 4 6 7; do
            maxfreq_path="/sys/devices/system/cpu/cpu$cpu/cpufreq/cpuinfo_max_freq"
            if [ -f "$maxfreq_path" ]; then
                maxfreq=$(cat "$maxfreq_path")
                if [ -n "$maxfreq" ] && [ "$maxfreq" -gt 0 ]; then
                    current_limit=$(grep "cpu$cpu" /sys/devices/virtual/thermal/thermal_message/cpu_limits)
                    if [ -z "$current_limit" ] || [ "$current_limit" != "cpu$cpu $maxfreq" ]; then
                        echo "cpu$cpu $maxfreq" > /sys/devices/virtual/thermal/thermal_message/cpu_limits
                    fi
                fi
            fi
        done
    fi
}

disable_ppm_policies() {
    if [ -d /proc/ppm ] && [ -f /proc/ppm/policy_status ]; then
        for idx in $(grep -E 'FORCE_LIMIT|PWR_THRO|THERMAL' /proc/ppm/policy_status | awk -F'[][]' '{print $2}'); do
            current_status=$(grep "^$idx " /proc/ppm/policy_status | awk '{print $2}')
            if [ "$current_status" != "0" ]; then
                echo "$idx 0" > /proc/ppm/policy_status
            fi
        done
    fi
}

hide_thermal_monitoring() {
    find /sys/devices/virtual/thermal -type f -exec sh -c '
        for file; do
            if [ "$(stat -c "%a" "$file")" != "0" ]; then
                chmod 000 "$file"
            fi
        done
    ' sh {} +
}

disable_thermal_stats() {
    if [ "$(cmd thermalservice get-status)" != "0" ]; then
        cmd thermalservice override-status 0
    fi
}

disable_charging_throttle() {
    if [ -f /proc/mtk_batoc_throttling/battery_oc_protect_stop ]; then
        if [ "$(cat /proc/mtk_batoc_throttling/battery_oc_protect_stop)" != "stop 1" ]; then
            echo "stop 1" > /proc/mtk_batoc_throttling/battery_oc_protect_stop
        fi
    fi
}

reset_thermal_properties() {
    getprop | awk -F '[][]' '/ro.*thermal/ {print $2}' | while read -r prop; do
        if [ "$(getprop "$prop")" != "0" ]; then
            resetprop -n "$prop" 0
        fi
    done

    for prop in $(getprop | grep thermal | cut -f1 -d] | cut -f2 -d[ | grep -F init.svc.); do
        if [ "$(getprop "$prop")" != "stopped" ]; then
            setprop "$prop" stopped
        fi
    done

    for prop in $(getprop | grep thermal | cut -f1 -d] | cut -f2 -d[ | grep -F init.svc_); do
        if [ "$(getprop "$prop")" != "" ]; then
            setprop "$prop" ""
        fi
    done
    
    log_activity "Disabling Thermal Resetprop"
}

#####################################
## Standard Mode Functions ##
#####################################

standard_mode() {
    log_activity "Running in NORMAL thermal mode"
    
    # Basic thermal disabling
    disable_thermal_zones 
    reset_thermal_properties
    
    # Moderate system modifications
    disable_gpu_limits
    set_cpu_limits
    
    # Basic thermal monitoring disable
    hide_thermal_monitoring
    disable_thermal_stats
    
    # Additional standard mode changes (from script 2)
    for dead in android.hardware.thermal-service.mediatek android.hardware.thermal@2.0-service.mtk; do
        stop "$dead"
    done
    
    # Change thermal zone policies to userspace in standard mode
    for zone2 in /sys/class/thermal/thermal_zone*/policy; do
        [ -f "$zone2" ] && echo "userspace" > "$zone2"
    done
}

#####################################
## Aggressive Mode Functions ##
#####################################

aggressive_mode() {
    log_activity "Running in INTENSE thermal mode"
    
    # Run all standard functions
    standard_mode
    
    # Additional aggressive modifications
    disable_ppm_policies
    disable_charging_throttle
    stop_thermal_services
    
    # Freeze all running thermal processes (from script 2)
    for pid in $(pgrep thermal); do
        kill -SIGSTOP "$pid"
    done
    
    # More aggressive GPU settings
    [ -f /sys/class/kgsl/kgsl-3d0/throttling ] && echo "0" > /sys/class/kgsl/kgsl-3d0/throttling
    [ -f /sys/class/kgsl/kgsl-3d0/force_clk_on ] && echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on
}

#####################################
## Main Execution ##
#####################################

case "$thermal_mode_satus" in
    "Intense")
        aggressive_mode
        notify_messaging="Intense thermal controls applied"
        ;;
    *)
        standard_mode
        notify_messaging="Normal thermal controls applied"
        ;;
esac

# Send notification
su -lp 2000 -c "cmd notification post -i 'file:///data/local/tmp/hollow_icon.png' -t 'Hollow Thermal' -I 'file:///data/local/tmp/hollow_icon.png' 'thermal' '$notify_messaging'" > /dev/null 2>&1

echo "Thermal management completed in $thermal_mode_satus mode"