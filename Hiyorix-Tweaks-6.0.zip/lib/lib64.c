#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdbool.h>

#define MAX_BUFFER_SIZE 256

char* read_package_name() {
    FILE* file = fopen("/data/adb/modules/hiyorix/lib/game.txt", "r");
    if (file == NULL) {
        perror("Error opening file");
        return NULL;
    }

    char buffer[MAX_BUFFER_SIZE];
    char* package_name = NULL;
    if (fgets(buffer, sizeof(buffer), file) != NULL) {
        char* newline = strchr(buffer, '\n');
        if (newline != NULL) {
            *newline = '\0';
        }
        package_name = strdup(buffer);
    }

    fclose(file);
    return package_name;
}

int get_pid_by_package_name(const char* package_name) {
    char command[MAX_BUFFER_SIZE];
    snprintf(command, sizeof(command), "pidof -s %s", package_name);
    char buffer[MAX_BUFFER_SIZE];
    FILE* pipe = popen(command, "r");
    if (pipe == NULL) {
        perror("Error executing pidof command");
        return 0;
    }
    if (fgets(buffer, sizeof(buffer), pipe) != NULL) {
        pclose(pipe);
        return atoi(buffer);
    }
    pclose(pipe);
    return 0;
}

void show_notification(const char* message) {
    char command[MAX_BUFFER_SIZE];
    snprintf(command, sizeof(command), "am start -a android.intent.action.MAIN -e toasttext \"%s\" -n me.toast/.MainActivity", message);
    system(command);
}

int main() {
    char* package_name = read_package_name();
    if (package_name == NULL) {
        fprintf(stderr, "Error reading package name from file\n");
        return 1;
    }

    int old_pid = 0;
    bool app_running = false;

    for (;;) {
        int pid = get_pid_by_package_name(package_name);

        if (pid > 0) {
            if (!app_running || pid != old_pid) {
                char renice_command[MAX_BUFFER_SIZE];
                sprintf(renice_command, "renice -n -20 -p %d", pid);
                system(renice_command);
                sprintf(renice_command, "ionice -c 1 -n 0 -p %d", pid);
                system(renice_command);
                sprintf(renice_command, "chrt -f -p 99 %d", pid);
                system(renice_command);

                char notification_message[MAX_BUFFER_SIZE];
                sprintf(notification_message, "~ %s sedang berjalan, Mengoptimalkan prioritas renice.", package_name);
                show_notification(notification_message);

                old_pid = pid;
                app_running = true;
            }
        } else {
            if (app_running) {
                char notification_message[MAX_BUFFER_SIZE];
                sprintf(notification_message, "~ %s berhenti berjalan.", package_name);
                show_notification(notification_message);

                char renice_reset_command[MAX_BUFFER_SIZE];
                sprintf(renice_reset_command, "renice -n 0 -p %d", old_pid);
                system(renice_reset_command);
                sprintf(renice_reset_command, "ionice -c 2 -n 5 -p %d", old_pid);
                system(renice_reset_command);
                sprintf(renice_reset_command, "chrt -r -p 0 %d", old_pid);
                system(renice_reset_command);

                old_pid = 0;
                app_running = false;
            }
        }
        sleep(1);
    }

    free(package_name);
    return 0;
}
