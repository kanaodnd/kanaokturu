#
# woi gendeng ki malaas ne ##
#
#

# Start the app
am start -n com.zeetaa.zeetaatweaks/.MainActivity
