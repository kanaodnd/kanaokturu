#!/system/bin/sh

# Module Configuration
SKIPMOUNT=false
PROPFILE=true
POSTFSDATA=true
LATESTARTSERVICE=true

# Create Stellar Directory
ui_print "- Startup Installing"
mkdir -p /data/stellar
touch /data/stellar/lock
touch /data/stellar/soc

# Game list
ui_print "- Setting Gamelist"
unzip -qo "$ZIPFILE" 'game.txt' -d "$MODPATH"
mv "$MODPATH/game.txt" "/data/stellar/game.txt"
rm -f "$MODPATH/game.txt"

# Webroot
ui_print "- Extracting Webroot"
unzip -qo "$ZIPFILE" 'webroot' -d "$MODPATH"

# Extract 
ui_print "- Extracting Stellar Icon"
unzip -qo "$ZIPFILE" 'stellar_icon.png' -d "$MODPATH"
mv "$MODPATH/webroot/stellar_icon.png" "/data/local/tmp/stellar_icon.png"
rm -f "$MODPATH/webroot/stellar_icon.png"

# Set Module Permissions
ui_print "- Setting Module Permission"
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive "$MODPATH/system/bin" 0 2000 0755 0755
chmod +x "$MODPATH/system/bin/stellars"
chmod +x "$MODPATH/system/bin/stellar_profiles"
chmod +x "$MODPATH/system/bin/stellars_obility"

# Extract Additional Files and move them
ui_print "- Extracting Additional Files"
unzip -qo "$ZIPFILE" 'service/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'common/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'system/*' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'service.sh' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'post-fs-data.sh' -d "$MODPATH"
unzip -qo "$ZIPFILE" 'system.prop' -d "$MODPATH"

# Easter Egg Messages
case "$((RANDOM % 15 + 1))" in
    1) ui_print "- A Wishes from a Kids for Stellar" ;;
    2) ui_print "- Anytime, call me Stellar" ;;
    3) ui_print "- Foggy? Don't stay too long!" ;;
    4) ui_print "- So Dark? Torch on side!" ;;
    5) ui_print "- Hero? Not again!" ;;
    6) ui_print "- Saving? No." ;;
    7) ui_print "- Stellar will guide you." ;;
    8) ui_print "- Hero rises in darkness." ;;
    9) ui_print "- Whispers ancient of stellar." ;;
    10) ui_print "- Adventure calls beyond." ;;
    11) ui_print "- Forest guards its mysteries." ;;
    12) ui_print "- Stars predict a legend." ;;
    13) ui_print "- Look, that's a Stellar!" ;;
    14) ui_print "- Stellar dropping all of them" ;;
    15) ui_print "- Nothing. a Wish from Stellar" ;;
esac

