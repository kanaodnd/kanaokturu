function e(e) {
    return e && e.__esModule ? e.default : e;
}

var t = globalThis,
    n = {},
    a = {},
    o = t.parcelRequirefbde;

if (null == o) {
    o = function(e) {
        if (e in n) return n[e].exports;
        if (e in a) {
            var t = a[e];
            delete a[e];
            var o = { id: e, exports: {} };
            n[e] = o;
            t.call(o.exports, o, o.exports);
            return o.exports;
        }
        var i = Error("Cannot find module '" + e + "'");
        throw (i.code = "MODULE_NOT_FOUND"), i;
    };
    o.register = function(e, t) {
        a[e] = t;
    };
    t.parcelRequirefbde = o;
}

(0, o.register)("27Lyk", function(e, t) {
    Object.defineProperty(e.exports, "register", {
        get: () => n,
        set: e => (n = e),
        enumerable: !0,
        configurable: !0
    });
    var n,
        a = new Map();
    n = function(e, t) {
        for (var n = 0; n < t.length - 1; n += 2) a.set(t[n], { baseUrl: e, path: t[n + 1] });
    };
});

o("27Lyk").register(new URL("", import.meta.url).toString(), JSON.parse('["gvBVN","index.db60a46a.js","jkrgM","48MX7"]'));

let i = 0;

function executeCommand(e, t) {
    return void 0 === t && (t = {}), new Promise((n, a) => {
        let o = `exec_callback_${Date.now()}_${i++}`;
        function c(e) {
            delete window[e];
        }
        window[o] = (e, t, a) => {
            n({ errno: e, stdout: t, stderr: a }), c(o);
        };
        try {
            ksu.exec(e, JSON.stringify(t), o);
        } catch (e) {
            a(e), c(o);
        }
    });
}

function EventEmitter() {
    this.listeners = {};
}

const randomMessages = [
    "Welcome Master!",
    "Tell me, what good things to feels alive",
    "Anything Will Be Fine",
    "Prove it, if you are underestimated",
    "No one's is weak",
    "For Those Knows, They Knows.",
    "Keep climbing to the top",
    "Cold But Not Cruel!",
    "Java Is The Best Language ",
    "Keep In The Way",
    "Remember something before do some",
    "There anyone seeing this message?",
    "Try touch grass outside !",
    "Fill you're time for useful !",
    "Cobalah Untuk Keluar Sesaat !",
    "Sakit Yang Terasa Hanya Kamu Yang Tahu!",
    "Apakah ini Nyata?",
    "Keep Dreaming",
    "PSHT or JSHT",
    "Look That Stellar Under Space"
];

function showRandomMessage() {
    const messageElement = document.getElementById("msg");
    const randomIndex = Math.floor(Math.random() * randomMessages.length);
    const message = randomMessages[randomIndex];

    messageElement.textContent = message;
}

window.onload = showRandomMessage;

function Process() {
    this.listeners = {};
    this.stdin = new EventEmitter();
    this.stdout = new EventEmitter();
    this.stderr = new EventEmitter();
}

function showToast(message) {
    ksu.toast(message);
}

EventEmitter.prototype.on = function(event, listener) {
    this.listeners[event] || (this.listeners[event] = []), this.listeners[event].push(listener);
};

EventEmitter.prototype.emit = function(event, ...args) {
    this.listeners[event] && this.listeners[event].forEach(listener => listener(...args));
};

Process.prototype.on = function(event, listener) {
    this.listeners[event] || (this.listeners[event] = []), this.listeners[event].push(listener);
};

Process.prototype.emit = function(event, ...args) {
    this.listeners[event] && this.listeners[event].forEach(listener => listener(...args));
};

var u = {};

async function checkModuleVersion() {
    let { errno: e, stdout: t } = await executeCommand('grep "version=" /data/adb/modules/stellar/module.prop | awk -F\'=\' \'{print $2}\'');
    0 === e && (document.getElementById("moduleVer").textContent = t.trim());
}

async function checkServiceStatus() {
    let { errno: t, stdout: n } = await executeCommand("pgrep -f stellars");
    if (0 === t) {
        let t = document.getElementById("serviceStatus");
        "0" != n.trim() ? (t.textContent = "Awake ✨ - 起きる", document.getElementById("servicePID").textContent = "Service PID: " + n.trim()) : (t.textContent = "Sleep 💤 - 寝る", document.getElementById("servicePID").textContent = "Service PID: null");
    }
}

async function checkTrimmingStatus() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/fstrim_part");
    if (0 === e) document.getElementById("trimming").checked = "1" === t.trim();
}

async function setTrimmingStatus(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/fstrim_part" : "echo 0 >/data/stellar/fstrim_part");
}

async function checkLoggerStatus() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/log");
    if (0 === e) document.getElementById("killLogger").checked = "1" === t.trim();
}

async function setLog(enabled) {
   showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/log" : "echo 0 >/data/stellar/log");
}

async function checkSurfaceFlingerStatus() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/surf_flinger");
    if (0 === e) document.getElementById("surface").checked = "1" === t.trim();
}

async function setSurfaceFlingerStatus(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/surf_flinger" : "echo 0 >/data/stellar/surf_flinger");
}

async function checkSpoofingStatus() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/spoofing");
    if (0 === e) document.getElementById("spoof").checked = "1" === t.trim();
}

async function setSpoofingStatus(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/spoofing" : "echo 0 >/data/stellar/spoofing");
}

async function startService() {
    await executeCommand("su -c /data/adb/modules/stellar/system/bin/stellars > /dev/null 2>&1 & disown"), await checkServiceStatus(), await getServicePID();
}

async function stopService() {
    await executeCommand("pkill -9 -f stellars"), await checkServiceStatus(), await getServicePID();
}

async function setDefaultCpuGovernor(governor) {
    await executeCommand("echo " + governor + " >/data/stellar/custom_default_cpu_gov");
}

async function setGameCpuGovernor(governor) {
    await executeCommand("echo " + governor + " >/data/stellar/custom_game_cpu_gov");
}

async function loadCpuGovernors() {
    let { errno: e, stdout: t } = await executeCommand("chmod 644 scaling_available_governors && cat scaling_available_governors", { cwd: "/sys/devices/system/cpu/cpu0/cpufreq" });
    if (0 === e) {
        let e = t.trim().split(/\s+/),
            n = document.getElementById("cpuGovernor"),
            a = document.getElementById("cpuGovernorGame");
        n.innerHTML = "", a.innerHTML = "";
        e.forEach(e => {
            let t = document.createElement("option");
            t.value = e, t.textContent = e, n.appendChild(t);
            let o = document.createElement("option");
            o.value = e, o.textContent = e, a.appendChild(o);
        });
        let { errno: o, stdout: i } = await executeCommand("[ -f custom_default_cpu_gov ] && cat custom_default_cpu_gov || cat default_cpu_gov", { cwd: "/data/stellar" });
        if (0 === o) {
            let e = i.trim();
            n.value = e;
        }
        let { errno: r, stdout: s } = await executeCommand("cat /data/stellar/custom_game_cpu_gov");
        if (0 === r) {
            let e = s.trim();
            a.value = e;
        }
    }
}


async function setLogBuffer() {
    await executeCommand("su -c stellar_obility set_log_buffer"), showToast("Executed");
}

async function checkdisableCPU() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/cpu");
    if (0 === e) document.getElementById("cpuLimit").checked = "1" === t.trim();
}

async function setCpuLimit(enabled) {
    showToast("Game option: no need reboot"), await executeCommand(enabled ? "echo 1 >/data/stellar/cpu" : "echo 0 >/data/stellar/cpu");
}

async function checkDex2oat() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/d2oat");
    if (0 === e) document.getElementById("dex2OAT").checked = "1" === t.trim();
}

async function dx2oats(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/d2oat" : "echo 0 >/data/stellar/d2oat");
}

async function checkSF2() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/surf_flinger2");
    if (0 === e) document.getElementById("surface2").checked = "1" === t.trim();
}

async function sf2(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/surf_flinger2" : "echo 0 >/data/stellar/surf_flinger2");
} 

async function gmsDdoze() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/gms");
    if (0 === e) document.getElementById("gmsDoze").checked = "1" === t.trim();
}

async function gms(enabled) {
    showToast("Reboot to apply"), await executeCommand(enabled ? "echo 1 >/data/stellar/gms" : "echo 0 >/data/stellar/gms");
} 

async function cpuHighh() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/cpu_high");
    if (0 === e) document.getElementById("cpuHigh").checked = "1" === t.trim();
}

async function cpuGeh(enabled) {
    showToast("Game option: no need reboot"), await executeCommand(enabled ? "echo 1 >/data/stellar/cpu_high" : "echo 0 >/data/stellar/cpu_high");
} 

async function bypass() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/bypass");
    if (0 === e) document.getElementById("geypass").checked = "1" === t.trim();
}

async function behpass(enabled) {
    showToast("Game option: no need reboot"), await executeCommand(enabled ? "echo 1 >/data/stellar/bypass" : "echo 0 >/data/stellar/bypass");
} 
   
async function checkDNDstatus() {
    let { errno: e, stdout: t } = await executeCommand("cat /data/stellar/dnd");
    if (0 === e) document.getElementById("DonotDis").checked = "1" === t.trim();
}

async function setDnd(enabled) {
    showToast("Game option: no need reboot"), await executeCommand(enabled ? "echo 1 >/data/stellar/dnd" : "echo 0 >/data/stellar/dnd");
}

async function showGameListModal() {
    let e = document.getElementById("gamelistModal"),
        t = document.getElementById("gamelistInput"),
        { errno: n, stdout: a } = await executeCommand("cat /data/stellar/game.txt");
    0 === n && (t.value = a.trim().replace(/\|/g, "\n")), e.classList.remove("hidden");
}

async function saveGameList() {
    let e = document.getElementById("gamelistInput").value.trim().replace(/\n+/g, "/");
    await executeCommand(`echo "${e}" | tr '/' '\n' > /data/stellar/game.txt`), showToast("Gamelist saved.");
}

async function openUrl(url) {
    await executeCommand(`/system/bin/am start -a android.intent.action.VIEW -d https://t.me/hosshi_prjkt`);
}

document.addEventListener('DOMContentLoaded', async function() {
    // Get loader elements
    const loadingProgress = document.querySelector('.loading-progress');
    const loadingText = document.querySelector('.loading-text');
    const loader = document.querySelector('.stellar-loader');
    
    // Initial message
    loadingText.textContent = "Wait Jawa Script is Ready..";
    
    // Smooth progress animation (0-100% in one pass)
    const animateProgress = () => {
        return new Promise(resolve => {
            const duration = 1000; // 2 seconds total animation
            const startTime = performance.now();
            
            const updateProgress = (currentTime) => {
                const elapsed = currentTime - startTime;
                const progress = Math.min(elapsed / duration * 100, 100);
                loadingProgress.style.width = `${progress}%`;
                
                if (progress < 100) {
                    requestAnimationFrame(updateProgress);
                } else {
                    resolve();
                }
            };
            
            requestAnimationFrame(updateProgress);
        });
    };
    
    // Run progress animation and initialization in parallel
    await Promise.all([
        animateProgress(),
        initializeAppTasks()
    ]);
    
    // Final message
    loadingText.textContent = "Jawa Script Ready !";
    loadingProgress.style.width = "100%";
    
    // Setup all interactive elements
    setupEventListeners();
    
    // Smooth fade out
    loader.classList.add('fade-out');
    setTimeout(() => loader.style.display = 'none', 500);
});

async function initializeAppTasks() {
    // Run all initialization tasks
    await checkModuleVersion();
    await checkServiceStatus();
    await checkTrimmingStatus();
    await checkLoggerStatus();
    await loadCpuGovernors();
    await checkdisableCPU();
    await checkSpoofingStatus();
    await checkSurfaceFlingerStatus();
    await checkDNDstatus();
    await checkDex2oat();
    await checkSF2();
    await bypass();
    await gmsDdoze();
    await cpuHighh();
    
}

function setupEventListeners() {
    // Word cycling animation
    const words = document.querySelectorAll('.word');
    let currentIndex = 0;
    function cycleWords() {
        words.forEach((word, index) => {
            word.style.display = index === currentIndex ? 'block' : 'none';
        });
        currentIndex = (currentIndex + 1) % words.length;
    }
    setInterval(cycleWords, 1000);

    // Service Controls
    document.getElementById("startButton").addEventListener("click", async () => {
        await startService();
    });
    
    document.getElementById("killService").addEventListener("click", async () => {
        await stopService();
    });

    // Toggle Listeners
    const createToggleHandler = (id, handler) => {
        document.getElementById(id).addEventListener("change", async function() {
            await handler(this.checked);
        });
    };

    createToggleHandler("surface2", sf2);
    createToggleHandler("gmsDoze", gms);
    createToggleHandler("geypass", behpass);
    createToggleHandler("cpuHigh", cpuGeh);
    createToggleHandler("dex2OAT", dx2oats);
    createToggleHandler("cpuLimit", setCpuLimit);
    createToggleHandler("DonotDis", setDnd);
    createToggleHandler("trimming", setTrimmingStatus);
    createToggleHandler("spoof", setSpoofingStatus);
    createToggleHandler("killLogger", setLog);
    createToggleHandler("surface", setSurfaceFlingerStatus);

    // CPU Governor Controls
    document.getElementById("cpuGovernorGame").addEventListener("change", async function() {
        await setGameCpuGovernor(this.value);
    });
    
    document.getElementById("cpuGovernor").addEventListener("change", async function() {
        await setDefaultCpuGovernor(this.value);
    });

    // Avatar Click
    document.getElementById("ch_link").addEventListener("click", () => {
        openUrl("");
    });

    // Warning Popup System
    const warningPopup = document.getElementById('warningPopup');
    const warningText = document.getElementById('warningText');
    
    document.querySelectorAll('.warning-button').forEach(button => {
        button.addEventListener('click', () => {
            warningText.textContent = button.getAttribute('data-info') || 
                "Disabling Joyouse (Miui/HyperOS), Game Optimization Service (GOS) in Oneui, Other things.";
            warningPopup.classList.add('active');
        });
    });
    
    document.getElementById("closePopup").addEventListener("click", () => {
        warningPopup.classList.remove('active');
    });

    // Game List Modal
    const gamelistModal = document.getElementById('gamelistModal');
    
    document.getElementById("editGamelistButton").addEventListener("click", () => {
        showGameListModal();
        gamelistModal.classList.add('active');
    });
    
    document.getElementById("cancelButton").addEventListener("click", () => {
        gamelistModal.classList.remove('active');
    });
    
    document.getElementById("saveGamelistButton").addEventListener("click", async () => {
        await saveGameList();
        gamelistModal.classList.remove('active');
    });
}

// Ensure all your async functions are defined:
// checkModuleVersion, startService, sf2, gms, etc...