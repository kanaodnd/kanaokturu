#!/system/bin/sh

# wait when its done
while [ "$(getprop sys.boot_completed | tr -d '\r')" != "1" ]; do sleep 35; done

sync

log_y="/sdcard/stellar.log"

# delete old logs
rm $log_y

# secondly ability
nohup stellar_obility > /dev/null 2>&1 &

# main service
stellars




